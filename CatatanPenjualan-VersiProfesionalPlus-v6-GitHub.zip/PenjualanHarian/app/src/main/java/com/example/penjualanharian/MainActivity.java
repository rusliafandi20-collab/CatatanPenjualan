package com.example.penjualanharian;

import android.app.*;import android.os.*;import android.content.*;import android.database.*;import android.text.*;import android.database.sqlite.*;import android.graphics.*;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout content, nav; TextView navDash,navTx,navReport; int page=0;
    final Locale ID=new Locale("id","ID"); final SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy",ID); final SimpleDateFormat monthFmt=new SimpleDateFormat("MMMM yyyy",ID);
    final NumberFormat nf=NumberFormat.getCurrencyInstance(ID);
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);} int green=Color.parseColor("#0F8F78"), dark=Color.parseColor("#12312B"), text=Color.parseColor("#18212F"), muted=Color.parseColor("#718096"), bg=Color.parseColor("#F5F7FA"), line=Color.parseColor("#E7ECEB"), profit=Color.parseColor("#079669");
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new DB(this); buildShell(); showPage(0);}
    TextView tv(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);return t;}
    GradientDrawable box(String c,float r){GradientDrawable g=new GradientDrawable();g.setColor(Color.parseColor(c));g.setCornerRadius(dp(r));return g;}
    GradientDrawable stroke(String fill,String sc,float r){GradientDrawable g=box(fill,r);g.setStroke(dp(1),Color.parseColor(sc));return g;}
    LinearLayout.LayoutParams lp(int w,int h,float l,float t,float r,float b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    void buildShell(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);setContentView(root);
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.VERTICAL);bar.setPadding(dp(20),dp(16),dp(20),dp(14));bar.setBackground(box("#0D806D",0));
        TextView title=tv("Catatan Penjualan",24,Color.WHITE,true);bar.addView(title); TextView sub=tv("Kelola usaha dengan lebih rapi dan terukur",13,Color.parseColor("#D8F5EF"),false);bar.addView(sub,lp(-1,-2,0,4,0,0)); root.addView(bar,new LinearLayout.LayoutParams(-1,-2));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setPadding(dp(8),dp(7),dp(8),dp(7));nav.setGravity(Gravity.CENTER);nav.setBackgroundColor(Color.WHITE);
        navDash=navItem("⌂","Dashboard",0);navTx=navItem("＋","Transaksi",1);navReport=navItem("▣","Laporan",2);nav.addView(navDash,new LinearLayout.LayoutParams(0,dp(58),1));nav.addView(navTx,new LinearLayout.LayoutParams(0,dp(58),1));nav.addView(navReport,new LinearLayout.LayoutParams(0,dp(58),1));root.addView(nav,new LinearLayout.LayoutParams(-1,dp(72)));
    }
    TextView navItem(String icon,String label,int idx){TextView t=tv(icon+"\n"+label,12,muted,true);t.setGravity(Gravity.CENTER);t.setOnClickListener(v->showPage(idx));return t;}
    void showPage(int p){page=p;content.removeAllViews(); if(p==0)dashboard(); else if(p==1)transactions(); else reports(); navDash.setTextColor(p==0?green:muted);navTx.setTextColor(p==1?green:muted);navReport.setTextColor(p==2?green:muted);}
    TextView section(String s){TextView t=tv(s,19,text,true);t.setPadding(0,dp(16),0,dp(9));return t;}
    TextView moneyCard(String label,String value,String color){TextView t=tv(label+"\n"+value,13,Color.parseColor(color),true);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(14),dp(12),dp(10),dp(12));t.setBackground(stroke("#FFFFFF",color,16));return t;}
    String rp(double x){return nf.format(x).replace(",00","").replace("Rp","Rp ");}
    String today(){return sdf.format(new Date());}
    void dashboard(){
        ScrollView sc=new ScrollView(this);LinearLayout root=col();root.setPadding(dp(16),dp(4),dp(16),dp(18));sc.addView(root);content.addView(sc);
        LinearLayout hero=col();hero.setPadding(dp(18),dp(18),dp(18),dp(18));hero.setBackground(box("#123D34",20)); TextView h=tv("Ringkasan Hari Ini",20,Color.WHITE,true);hero.addView(h);TextView d=tv(new SimpleDateFormat("EEEE, dd MMMM yyyy",ID).format(new Date()),13,Color.parseColor("#BFE8DF"),false);hero.addView(d,lp(-1,-2,0,4,0,0));
        double[] a=db.summary(today(),today()); double netOmset=a[0]-a[3], netLaba=netOmset-a[1]; TextView main=tv("Omset Bersih\n"+rp(netOmset),26,Color.WHITE,true);main.setPadding(0,dp(18),0,dp(2));hero.addView(main);TextView small=tv("Omset kotor "+rp(a[0])+"  •  Kontrak "+rp(a[3])+"\nLaba bersih  "+rp(netLaba)+"  •  "+(int)a[2]+" transaksi",13,Color.parseColor("#D8F5EF"),false);hero.addView(small);root.addView(hero,lp(-1,-2,0,10,0,0));
        root.addView(section("Ikhtisar Keuangan"));LinearLayout r1=row();r1.addView(moneyCard("OMSET KOTOR",rp(a[0]),"#0F8F78"),new LinearLayout.LayoutParams(0,dp(82),1));r1.addView(moneyCard("UANG KONTRAK",rp(a[3]),"#C2410C"),new LinearLayout.LayoutParams(0,dp(82),1));root.addView(r1,lp(-1,-2,0,0,0,0));
        LinearLayout r2=row();r2.addView(moneyCard("MODAL",rp(a[1]),"#B7791F"),new LinearLayout.LayoutParams(0,dp(82),1));r2.addView(moneyCard("LABA BERSIH",rp(netLaba),"#07855F"),new LinearLayout.LayoutParams(0,dp(82),1));root.addView(r2,lp(-1,-2,0,10,0,0));
        double[] all=db.summary("01/01/1900","31/12/2999"); double allNet=all[0]-all[3], allProfit=allNet-all[1]; LinearLayout r3=row();r3.addView(moneyCard("TOTAL OMSET BERSIH",rp(allNet),"#2563EB"),new LinearLayout.LayoutParams(0,dp(82),1));r3.addView(moneyCard("TOTAL LABA BERSIH",rp(allProfit),"#7C3AED"),new LinearLayout.LayoutParams(0,dp(82),1));root.addView(r3,lp(-1,-2,0,10,0,0));
        // Ringkasan bulanan ditampilkan langsung di dashboard
        root.addView(section("Ringkasan Bulan Ini"));
        LinearLayout monthlyCard=col();monthlyCard.setPadding(dp(14),dp(14),dp(14),dp(14));
        monthlyCard.setBackground(box("#FFFFFF",18));
        String monthName=new SimpleDateFormat("MMMM yyyy",ID).format(new Date());
        double[] m=db.monthSummary(new Date());
        double mNet=m[0]-m[3], mProfit=mNet-m[1];
        TextView mt=tv(monthName,15,text,true);
        monthlyCard.addView(mt,lp(-1,-2,0,0,0,9));

        LinearLayout mr1=row();
        mr1.addView(moneyCard("OMSET BULANAN",rp(mNet),"#0F8F78"),new LinearLayout.LayoutParams(0,dp(78),1));
        mr1.addView(moneyCard("MODAL BULANAN",rp(m[1]),"#B7791F"),new LinearLayout.LayoutParams(0,dp(78),1));
        monthlyCard.addView(mr1,lp(-1,-2,0,0,0,8));

        LinearLayout mr2=row();
        mr2.addView(moneyCard("KONTRAK BULANAN",rp(m[3]),"#2563EB"),new LinearLayout.LayoutParams(0,dp(78),1));
        mr2.addView(moneyCard("LABA BERSIH BULANAN",rp(mProfit),"#7C3AED"),new LinearLayout.LayoutParams(0,dp(78),1));
        monthlyCard.addView(mr2,lp(-1,-2,0,0,0,8));

        TextView mtCount=tv("Total transaksi bulan ini: "+(int)m[2],12,muted,true);
        mtCount.setPadding(0,dp(4),0,0);
        monthlyCard.addView(mtCount);
        root.addView(monthlyCard,lp(-1,-2,0,10,0,12));

        LinearLayout head=row();head.addView(section("Transaksi Terbaru"),new LinearLayout.LayoutParams(0,-2,1));Button see=smallBtn("Lihat Semua");see.setOnClickListener(v->showPage(1));head.addView(see);root.addView(head);
        LinearLayout list=col();Cursor c=db.recent(5);while(c.moveToNext()) list.addView(txCard(c,true),lp(-1,-2,0,0,0,9));c.close(); if(list.getChildCount()==0){TextView e=tv("Belum ada transaksi. Tambahkan transaksi pertama Anda.",14,muted,false);e.setGravity(Gravity.CENTER);e.setPadding(0,dp(20),0,dp(20));list.addView(e);}root.addView(list);
    }
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    Button smallBtn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(green);b.setAllCaps(false);b.setBackground(stroke("#FFFFFF","#CFE1DC",12));return b;}
    void transactions(){
        ScrollView sc=new ScrollView(this);LinearLayout root=col();
        root.setPadding(dp(16),dp(4),dp(16),dp(18));sc.addView(root);content.addView(sc);

        Button manage=smallBtn("⚙ Kelola Produk");
        manage.setOnClickListener(v->manageProducts());
        root.addView(manage,lp(-1,46,0,2,0,8));
        root.addView(section("Tambah Transaksi Penjualan"));
        TextView expl=tv("Satu transaksi dapat berisi beberapa produk. Masukkan total penjualan dan total modal secara terpisah.",12,muted,false);
        root.addView(expl,lp(-1,-2,0,0,0,10));

        LinearLayout form=col();form.setPadding(dp(14),dp(14),dp(14),dp(14));form.setBackground(box("#FFFFFF",18));

        EditText date=field("Tanggal transaksi",false);date.setText(today());
        date.setOnClickListener(v->pickDate(date));date.setFocusable(false);
        date.setCompoundDrawablesWithIntrinsicBounds(0,0,android.R.drawable.ic_menu_my_calendar,0);
        form.addView(date,lp(-1,52,0,0,0,9));

        Spinner product=productSpinner();
        form.addView(product,lp(-1,52,0,0,0,9));

        EditText qty=field("Jumlah item (pcs)",true);
        qty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        qty.setText("1");
        form.addView(qty,lp(-1,52,0,0,0,9));

        EditText sale=field("Total penjualan (Rp)",true);
        attachMoneyFormatter(sale);
        form.addView(sale,lp(-1,52,0,0,0,9));

        EditText capital=field("Total modal (Rp)",true);
        attachMoneyFormatter(capital);
        form.addView(capital,lp(-1,52,0,0,0,9));

        TextView hint=tv("Pilih produk yang sudah tersimpan, lalu isi jumlah pcs. Total penjualan dan modal tetap merupakan akumulasi transaksi.",11,muted,false);
        form.addView(hint,lp(-1,-2,0,2,0,9));

        EditText note=field("Catatan (opsional)",true);
        form.addView(note,lp(-1,52,0,0,0,9));

        Button save=new Button(this);save.setText("SIMPAN TRANSAKSI");
        save.setTextColor(Color.WHITE);save.setTextSize(14);save.setAllCaps(false);
        save.setTypeface(Typeface.DEFAULT,Typeface.BOLD);save.setBackground(box("#0F8F78",14));
        form.addView(save,new LinearLayout.LayoutParams(-1,52));root.addView(form);

        save.setOnClickListener(v->{
            try{
                String t=date.getText().toString(),p=String.valueOf(product.getSelectedItem());
                int count=Integer.parseInt(qty.getText().toString().trim());
                double totalSale=parseMoney(sale.getText().toString());
                double totalModal=parseMoney(capital.getText().toString());
                if(p.equals("Pilih produk...")||count<=0||totalSale<=0||totalModal<0)throw new Exception();
                db.add(t,p,count,totalSale,totalSale,totalModal,note.getText().toString().trim());
                product.setSelection(0);qty.setText("1");sale.setText("");capital.setText("");note.setText("");
                refreshTransactions(root);
                Toast.makeText(this,"Transaksi tersimpan",Toast.LENGTH_SHORT).show();
            }catch(Exception e){
                Toast.makeText(this,"Isi produk, total penjualan, dan total modal dengan benar",Toast.LENGTH_LONG).show();
            }
        });
        refreshTransactions(root);
    }

    Spinner productSpinner(){
        Spinner s=new Spinner(this);
        ArrayList<String> items=new ArrayList<>();items.add("Pilih produk...");
        Cursor c=db.products();while(c.moveToNext())items.add(c.getString(0));c.close();
        if(items.size()==1)items.add("Belum ada produk tersimpan");
        ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,items);
        s.setAdapter(a);s.setBackground(stroke("#FAFCFC","#DCE5E2",14));
        return s;
    }

    EditText field(String hint,boolean numeric){return field(hint,"",numeric);}
    EditText field(String hint,String val,boolean numeric){
        EditText e=new EditText(this);e.setHint(hint);e.setText(val);e.setTextSize(14);
        e.setTextColor(text);e.setHintTextColor(Color.parseColor("#9AA5B1"));
        e.setPadding(dp(14),0,dp(14),0);e.setSingleLine(true);
        e.setBackground(stroke("#FAFCFC","#DCE5E2",14));
        if(numeric)e.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        return e;
    }
    double parseMoney(String value){
        if(value==null)return 0;
        String digits=value.replaceAll("[^0-9]","");
        if(digits.isEmpty())return 0;
        return Double.parseDouble(digits);
    }
    void attachMoneyFormatter(EditText e){
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.addTextChangedListener(new android.text.TextWatcher(){
            boolean busy=false;
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){}
            public void afterTextChanged(android.text.Editable s){
                if(busy)return;
                String digits=s.toString().replaceAll("[^0-9]","");
                if(digits.isEmpty())return;
                try{
                    long n=Long.parseLong(digits);
                    String formatted=String.format(Locale.US,"%,d",n).replace(',','.');
                    if(!formatted.equals(s.toString())){
                        busy=true;
                        e.setText(formatted);
                        e.setSelection(formatted.length());
                        busy=false;
                    }
                }catch(Exception ignored){}
            }
        });
    }

    void manageProducts(){
        LinearLayout box=col();box.setPadding(dp(18),dp(10),dp(18),dp(4));
        EditText name=field("Nama produk, contoh: Topi",true);box.addView(name,lp(-1,52,0,0,0,10));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Kelola Produk").setView(box).setPositiveButton("Tambah",null).setNegativeButton("Tutup",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String n=name.getText().toString().trim();
            if(!n.isEmpty()){db.addProduct(n);name.setText("");Toast.makeText(this,"Produk ditambahkan",Toast.LENGTH_SHORT).show();}
        }));
        dlg.show();
    }

    void pickDate(EditText target){Calendar c=Calendar.getInstance();try{c.setTime(sdf.parse(target.getText().toString()));}catch(Exception ignored){}new DatePickerDialog(this,(v,y,m,d)->{Calendar x=Calendar.getInstance();x.set(y,m,d);target.setText(sdf.format(x.getTime()));},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    void refreshTransactions(LinearLayout root){while(root.getChildCount()>2)root.removeViewAt(2);root.addView(section("Total Transaksi Harian")); addDailySummary(root,today()); root.addView(section("Transaksi Hari Ini"));TextView hint=tv("Tekan lama transaksi untuk menghapus.",12,muted,false);root.addView(hint);LinearLayout list=col();Cursor c=db.byDate(today());while(c.moveToNext())list.addView(txCard(c,false),lp(-1,-2,0,8,0,0));c.close();if(list.getChildCount()==0){TextView e=tv("Belum ada transaksi hari ini.",14,muted,false);e.setGravity(Gravity.CENTER);e.setPadding(0,dp(24),0,dp(24));list.addView(e);}root.addView(list);}
    void addDailySummary(LinearLayout root,String date){double[] a=db.summary(date,date);double net=a[0]-a[3], lab=net-a[1];LinearLayout card=col();card.setPadding(dp(15),dp(14),dp(15),dp(14));card.setBackground(stroke("#FFFFFF","#DCE7E3",18));TextView title=tv("Ringkasan "+date,14,muted,true);card.addView(title);LinearLayout r=row();r.setPadding(0,dp(10),0,dp(5));r.addView(tv("Omset kotor\n"+rp(a[0]),12,text,true),new LinearLayout.LayoutParams(0,-2,1));r.addView(tv("Modal\n"+rp(a[1]),12,Color.parseColor("#B7791F"),true),new LinearLayout.LayoutParams(0,-2,1));r.addView(tv("Laba bersih\n"+rp(lab),12,profit,true),new LinearLayout.LayoutParams(0,-2,1));card.addView(r);LinearLayout rr=row();rr.addView(tv("Omset bersih: "+rp(net),14,text,true),new LinearLayout.LayoutParams(0,-2,1));Button contract=smallBtn("Uang Kontrak");contract.setOnClickListener(v->showContractDialog(date));rr.addView(contract,new LinearLayout.LayoutParams(dp(126),48));card.addView(rr);TextView ct=tv("Uang kontrak: "+rp(a[3])+"  •  Transaksi: "+(int)a[2],12,muted,false);card.addView(ct,lp(-1,-2,0,7,0,0));root.addView(card,lp(-1,-2,0,0,0,10));}
    void showContractDialog(String date){final EditText input=field("Nominal uang kontrak",true);attachMoneyFormatter(input);input.setText(db.getContract(date)>0?String.format(Locale.US,"%,d",(long)db.getContract(date)).replace(',','.'):"");LinearLayout wrap=col();wrap.setPadding(dp(8),dp(4),dp(8),0);wrap.addView(input,new LinearLayout.LayoutParams(-1,54));AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Uang Kontrak — "+date).setMessage("Nominal ini akan otomatis mengurangi omset penjualan dan laba bersih pada tanggal tersebut.").setView(wrap).setNegativeButton("Batal",null).setNeutralButton("Hapus",null).setPositiveButton("Simpan",null).create();dlg.setOnShowListener(x->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{double val=parseMoney(input.getText().toString());if(val<0)throw new Exception();db.setContract(date,val);dlg.dismiss();transactions();Toast.makeText(this,"Uang kontrak diperbarui",Toast.LENGTH_SHORT).show();}catch(Exception e){input.setError("Masukkan nominal yang benar");}});dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{db.setContract(date,0);dlg.dismiss();transactions();Toast.makeText(this,"Uang kontrak dihapus",Toast.LENGTH_SHORT).show();});});dlg.show();}
    View txCard(Cursor c,boolean compact){long id=c.getLong(0);String date=c.getString(1),pr=c.getString(2);int q=c.getInt(3);double sale=c.getDouble(5),mo=c.getDouble(6),lb=sale-mo;boolean primary=c.getColumnCount()<10||c.getInt(9)==1;String note=c.getString(7);LinearLayout card=col();card.setPadding(dp(15),dp(13),dp(15),dp(13));card.setBackground(stroke("#FFFFFF","#E6ECEA",16));LinearLayout top=row();top.addView(tv(pr,16,text,true),new LinearLayout.LayoutParams(0,-2,1));top.addView(tv(date,11,muted,false));card.addView(top);TextView detail=tv("Jumlah "+q+" pcs"+(primary?"   •   Total transaksi "+rp(sale):""),13,Color.parseColor("#475569"),false);detail.setPadding(0,dp(7),0,dp(3));card.addView(detail);LinearLayout b=row();b.addView(tv(primary?"Modal "+rp(mo):"Item dalam transaksi",12,Color.parseColor("#B7791F"),false),new LinearLayout.LayoutParams(0,-2,1));b.addView(primary?tv("Laba "+rp(lb),13,lb>=0?profit:Color.RED,true):tv("",13,text,false));card.addView(b);if(!compact&&note!=null&&!note.isEmpty())card.addView(tv("Catatan: "+note,12,muted,false),lp(-1,-2,0,7,0,0));card.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("Hapus transaksi?").setMessage(pr+"\n"+rp(sale)).setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{db.del(id);if(page==1)transactions();else dashboard();}).show();return true;});return card;}
    void reports(){
        ScrollView sc=new ScrollView(this);LinearLayout root=col();root.setPadding(dp(16),dp(4),dp(16),dp(20));sc.addView(root);content.addView(sc);
        LinearLayout head=col();head.setPadding(dp(18),dp(18),dp(18),dp(18));head.setBackground(box("#123D34",20));head.addView(tv("LAPORAN PENJUALAN HARIAN",20,Color.WHITE,true));head.addView(tv("Rekap transaksi, uang kontrak, omset, modal dan laba bersih",12,Color.parseColor("#BFE8DF"),false),lp(-1,-2,0,5,0,0));Date selected=reportDate==null?new Date():reportDate;head.addView(tv("PERIODE LAPORAN\n"+monthFmt.format(selected),12,Color.WHITE,true),lp(-1,-2,0,16,0,0));root.addView(head,lp(-1,-2,0,10,0,12));
        LinearLayout picker=row();TextView period=tv(monthFmt.format(selected),16,text,true);picker.addView(period,new LinearLayout.LayoutParams(0,52,1));Button month=smallBtn("Pilih Bulan");picker.addView(month,new LinearLayout.LayoutParams(dp(120),52));root.addView(picker);month.setOnClickListener(v->pickMonth(period));
        double[] a=db.monthSummary(selected);double net=a[0]-a[3], lab=net-a[1];LinearLayout cards=row();cards.addView(moneyCard("OMSET BERSIH",rp(net),"#0F8F78"),new LinearLayout.LayoutParams(0,86,1));cards.addView(moneyCard("UANG KONTRAK",rp(a[3]),"#C2410C"),new LinearLayout.LayoutParams(0,86,1));root.addView(cards,lp(-1,-2,0,12,0,0));LinearLayout cards2=row();cards2.addView(moneyCard("MODAL",rp(a[1]),"#B7791F"),new LinearLayout.LayoutParams(0,86,1));cards2.addView(moneyCard("LABA BERSIH",rp(lab),"#07855F"),new LinearLayout.LayoutParams(0,86,1));root.addView(cards2,lp(-1,-2,0,10,0,12));
        root.addView(section("Tabel Detail Laporan"));TextView desc=tv("Periode: "+monthFmt.format(selected)+"  •  Seluruh nominal dalam Rupiah",12,muted,false);root.addView(desc,lp(-1,-2,0,0,0,8));
        HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout table=col();table.setBackground(stroke("#FFFFFF","#DCE5E2",12));
        table.addView(reportRow(new String[]{"TANGGAL","TRX","OMSET KOTOR","KONTRAK","OMSET BERSIH","MODAL","LABA BERSIH"},true));
        Cursor c=db.dailyMonth(selected);int rows=0;while(c.moveToNext()){String day=c.getString(0),products=c.getString(1);int trx=c.getInt(2);double o=c.getDouble(3),m=c.getDouble(4),k=c.getDouble(5);double n=o-k,l=n-m;table.addView(reportRow(new String[]{day,products==null?"-":products,String.valueOf(trx),rp(o),rp(k),rp(n),rp(m),rp(l)},false));rows++;}c.close();if(rows==0)table.addView(reportRow(new String[]{"Belum ada data","-","-","-","-","-","-"},false));hs.addView(table);root.addView(hs,lp(-1,-2,0,0,0,0));
        LinearLayout total=col();total.setPadding(dp(14),dp(14),dp(14),dp(14));total.setBackground(box("#F0F8F5",14));total.addView(tv("TOTAL PERIODE",12,green,true));total.addView(tv("Omset kotor     "+rp(a[0])+"\nUang kontrak     "+rp(a[3])+"\nOmset bersih     "+rp(net)+"\nModal            "+rp(a[1])+"\nLaba bersih      "+rp(lab)+"\nJumlah transaksi "+(int)a[2],13,text,true),lp(-1,-2,0,8,0,0));root.addView(total,lp(-1,-2,0,10,0,0));
        Button share=new Button(this);share.setText("Bagikan Laporan");share.setAllCaps(false);share.setTextColor(green);share.setBackground(stroke("#FFFFFF","#CFE1DC",14));share.setOnClickListener(v->shareReport(a));root.addView(share,lp(-1,50,0,12,0,0));
    }
    View reportRow(String[] cells,boolean header){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(8),dp(10),dp(8),dp(10));r.setBackgroundColor(header?Color.parseColor("#EAF3F0"):Color.WHITE);int[] widths={95,230,55,125,105,125,105,125};for(int i=0;i<cells.length;i++){TextView t=tv(cells[i],header?10:11,header?dark:text,header||i==6);t.setGravity(i==0?Gravity.CENTER_VERTICAL:Gravity.CENTER);r.addView(t,new LinearLayout.LayoutParams(dp(widths[i]),-2));}return r;}
    void pickMonth(TextView title){Calendar c=Calendar.getInstance();Date base=reportDate==null?new Date():reportDate;c.setTime(base);new DatePickerDialog(this,(v,y,m,d)->{Calendar x=Calendar.getInstance();x.set(y,m,1);title.setText(monthFmt.format(x.getTime()));showMonthReport(x.getTime());},c.get(Calendar.YEAR),c.get(Calendar.MONTH),1).show();}
    void showMonthReport(Date d){reportDate=d;reports();}
    Date reportDate=null;
    void shareReport(double[] a){double net=a[0]-a[3],lab=net-a[1];String s="LAPORAN PENJUALAN HARIAN\n"+monthFmt.format(reportDate==null?new Date():reportDate)+"\n\nOmset Kotor: "+rp(a[0])+"\nUang Kontrak: "+rp(a[3])+"\nOmset Bersih: "+rp(net)+"\nModal: "+rp(a[1])+"\nLaba Bersih: "+rp(lab)+"\nTransaksi: "+(int)a[2];Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Bagikan laporan"));}
    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"sales.db",null,6);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,tanggal TEXT,produk TEXT,jumlah INTEGER,harga REAL,penjualan REAL,modal REAL,catatan TEXT,transaction_id TEXT,primary_item INTEGER DEFAULT 1)");
            d.execSQL("CREATE TABLE contracts(tanggal TEXT PRIMARY KEY,nominal REAL NOT NULL DEFAULT 0)");
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,nama TEXT UNIQUE NOT NULL)");
        }
        public void onUpgrade(SQLiteDatabase d,int a,int b){
            if(a<4)d.execSQL("CREATE TABLE IF NOT EXISTS contracts(tanggal TEXT PRIMARY KEY,nominal REAL NOT NULL DEFAULT 0)");
            if(a<5)d.execSQL("CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,nama TEXT UNIQUE NOT NULL)");
            if(a<6){
                d.execSQL("ALTER TABLE sales ADD COLUMN transaction_id TEXT");
                d.execSQL("ALTER TABLE sales ADD COLUMN primary_item INTEGER DEFAULT 1");
            }
        }
        void add(String t,String p,int q,double h,double j,double m,String c,String group,boolean primary){
            getWritableDatabase().execSQL("INSERT INTO sales(tanggal,produk,jumlah,harga,penjualan,modal,catatan,transaction_id,primary_item) VALUES(?,?,?,?,?,?,?,?,?)",
                new Object[]{t,p,q,h,j,m,c,group,primary?1:0});
        }
        void addProduct(String name){getWritableDatabase().execSQL("INSERT OR IGNORE INTO products(nama) VALUES(?)",new Object[]{name});}
        Cursor products(){return getReadableDatabase().rawQuery("SELECT nama FROM products ORDER BY nama COLLATE NOCASE",null);}
        void del(long id){getWritableDatabase().delete("sales","id=?",new String[]{String.valueOf(id)});}
        Cursor byDate(String t){return getReadableDatabase().rawQuery("SELECT id,tanggal,produk,jumlah,harga,penjualan,modal,catatan,transaction_id,primary_item FROM sales WHERE tanggal=? ORDER BY id DESC",new String[]{t});}
        Cursor recent(int n){return getReadableDatabase().rawQuery("SELECT id,tanggal,produk,jumlah,harga,penjualan,modal,catatan,transaction_id,primary_item FROM sales ORDER BY id DESC LIMIT "+n,null);}
        double contract(String date){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(nominal,0) FROM contracts WHERE tanggal=?",new String[]{date});double v=0;if(c.moveToFirst())v=c.getDouble(0);c.close();return v;}
        double getContract(String date){return contract(date);}
        void setContract(String date,double val){SQLiteDatabase w=getWritableDatabase();if(val<=0)w.delete("contracts","tanggal=?",new String[]{date});else w.execSQL("INSERT OR REPLACE INTO contracts(tanggal,nominal) VALUES(?,?)",new Object[]{date,val});}
        double[] summary(String from,String to){
            Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(penjualan),0),COALESCE(SUM(modal),0),COUNT(DISTINCT COALESCE(transaction_id,'legacy-'||id)),COALESCE((SELECT SUM(nominal) FROM contracts WHERE tanggal>=? AND tanggal<=?),0) FROM sales WHERE tanggal>=? AND tanggal<=?",
                new String[]{from,to,from,to});
            c.moveToFirst();double[] a={c.getDouble(0),c.getDouble(1),c.getDouble(2),c.getDouble(3)};c.close();return a;
        }
        double[] monthSummary(Date d){
            Calendar x=Calendar.getInstance();x.setTime(d);String prefix=new SimpleDateFormat("MM/yyyy",Locale.US).format(x.getTime());
            Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(penjualan),0),COALESCE(SUM(modal),0),COUNT(DISTINCT COALESCE(transaction_id,'legacy-'||id)),COALESCE((SELECT SUM(nominal) FROM contracts WHERE substr(tanggal,4,7)=?),0) FROM sales WHERE substr(tanggal,4,7)=?",
                new String[]{prefix,prefix});
            c.moveToFirst();double[] a={c.getDouble(0),c.getDouble(1),c.getDouble(2),c.getDouble(3)};c.close();return a;
        }
        Cursor dailyMonth(Date d){
            Calendar x=Calendar.getInstance();x.setTime(d);String prefix=new SimpleDateFormat("MM/yyyy",Locale.US).format(x.getTime());
            return getReadableDatabase().rawQuery("SELECT s.tanggal,group_concat(s.produk,' • '),COUNT(DISTINCT COALESCE(s.transaction_id,'legacy-'||s.id)),SUM(s.penjualan),SUM(s.modal),COALESCE((SELECT nominal FROM contracts ct WHERE ct.tanggal=s.tanggal),0) FROM sales s WHERE substr(s.tanggal,4,7)=? GROUP BY s.tanggal ORDER BY s.tanggal DESC",new String[]{prefix});
        }
    }

}
