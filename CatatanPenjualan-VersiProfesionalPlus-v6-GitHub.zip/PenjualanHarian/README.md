# Catatan Penjualan — Versi Profesional Plus 2.0

Fitur:
- Dashboard profesional
- Transaksi dan laporan terpisah
- Tanggal dipilih dari kalender Android
- Satu transaksi dapat berisi beberapa produk
- Total penjualan dan total modal diinput terpisah
- Laba transaksi = total penjualan - total modal
- Uang kontrak mengurangi omset bersih dan laba bersih harian
- Nominal Rupiah otomatis menggunakan titik pemisah ribuan (contoh 1000000 → 1.000.000)
- Laporan tabel profesional
- Data tersimpan offline
- Ikon aplikasi custom
- GitHub Actions untuk build APK

- Dashboard menampilkan total transaksi harian dan ringkasan transaksi bulanan secara bersamaan.

- Dashboard menampilkan semua transaksi hari ini (produk, penjualan, modal, laba).
- Laporan bulanan menampilkan daftar produk/transaksi per tanggal.

## Versi 5.0
- Katalog produk: pilih item yang sudah dimasukkan ke aplikasi.
- Jumlah item/pcs per transaksi.
- Kelola produk dari halaman transaksi.
- Dashboard menampilkan seluruh transaksi hari ini.
- Laporan menampilkan daftar produk/transaksi per tanggal.
