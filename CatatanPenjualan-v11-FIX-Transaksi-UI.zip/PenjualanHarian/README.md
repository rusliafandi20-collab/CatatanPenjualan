# Catatan Penjualan 9.0

Aplikasi pencatatan penjualan harian untuk Android.

## Pembaruan UI 9.0
- Gaya UI mengikuti referensi Sales Order: header teal, kartu putih membulat, input bersih, tombol aksi utama, dan hierarki visual yang konsisten.
- Semua jendela memakai header yang sama dengan tombol menu garis tiga dan menu titik tiga.
- Menu samping berisi Dashboard, Transaksi, Laporan, Kelola Produk, dan Tentang aplikasi.
- Layout adaptif untuk HP kecil, HP besar, landscape, dan tablet.
- Grid ringkasan otomatis menyesuaikan lebar layar.
- Form transaksi tetap mempertahankan fitur produk, jumlah, penjualan, modal, catatan, dan uang kontrak.
- Keyboard dan scrolling tetap menggunakan mode resize agar input tidak tertutup.

Minimum Android: API 23.
Target Android: API 35.
