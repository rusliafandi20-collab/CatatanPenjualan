# Catatan Penjualan

Android app Catatan Penjualan.

## Build APK di GitHub Actions

1. Upload seluruh isi repository ini ke root repository GitHub.
2. Buka tab **Actions**.
3. Pilih **Build Catatan Penjualan APK**.
4. Tekan **Run workflow**.
5. Setelah berhasil, ambil APK dari bagian **Artifacts** dengan nama `CatatanPenjualan-debug`.

Project Android berada langsung di root repository, sehingga `settings.gradle` dan folder `app` tidak berada di dalam folder tambahan.
