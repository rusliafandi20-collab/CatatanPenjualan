Catatan Penjualan v12.0 - stable build.

Perbaikan: build Java bersih, migrasi database lebih aman, dan halaman Transaksi tidak mematikan aplikasi saat data produk belum tersedia.
