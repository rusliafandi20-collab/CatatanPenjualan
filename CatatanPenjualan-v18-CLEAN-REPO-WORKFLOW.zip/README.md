# Catatan Penjualan v18

Repository-ready Android project.

Perubahan transaksi:
- Tombol Simpan Transaksi lebih besar dan alert setelah tersimpan.
- Ringkasan dan Riwayat Hari Ini langsung diperbarui.
- Banyak item satu transaksi digabung menjadi satu baris.
- Tombol Tambah Produk dan Pilih Produk lebih besar.
- Input tanggal, total penjualan, total modal, dan catatan lebih lebar.
- Gear Produk menampilkan daftar produk tersimpan.
- Simpan Produk menampilkan alert dan langsung tersedia di transaksi.
- Laporan memiliki Detail Transaksi satu baris per transaksi.
