# Catatan Penjualan Harian

Aplikasi Android offline untuk mencatat transaksi penjualan harian.

## Fitur
- Dashboard omset, modal, laba bersih, dan jumlah transaksi.
- Tambah transaksi: tanggal, produk, jumlah, harga jual, modal, catatan.
- Filter Hari Ini, Bulan Ini, atau Semua.
- Ketuk transaksi untuk edit.
- Tekan lama transaksi untuk hapus.
- Export/bagikan laporan CSV.
- Data tersimpan lokal di HP.
- GitHub Actions otomatis membangun APK debug.

## Build APK di GitHub
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder project ini (jangan upload ZIP sebagai satu file jika ingin Actions berjalan).
3. Buka tab **Actions** → workflow **Build Android APK** → **Run workflow**.
4. Setelah selesai, buka hasil workflow → bagian **Artifacts** → download `CatatanPenjualan-debug-apk`.
5. Ekstrak ZIP artifact dan install `app-debug.apk` di HP.

APK debug cocok untuk penggunaan pribadi/testing. Untuk rilis Play Store, buat signing key dan release build terpisah.
