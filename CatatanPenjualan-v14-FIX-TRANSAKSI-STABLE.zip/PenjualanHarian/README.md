# Catatan Penjualan v14
Perbaikan crash saat membuka menu Transaksi. Navigasi dari popup ditunda ke UI queue, halaman dibungkus error handler agar aplikasi tidak langsung keluar, dan pemuatan riwayat transaksi dilakukan setelah halaman tampil.
