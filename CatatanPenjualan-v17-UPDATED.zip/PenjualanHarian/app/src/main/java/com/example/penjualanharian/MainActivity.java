package com.example.penjualanharian;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.text.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout content, nav; TextView navDash, navTx, navReport; int page=0;
    final Locale ID=new Locale("id","ID");
    final SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy",ID);
    final SimpleDateFormat monthFmt=new SimpleDateFormat("MMMM yyyy",ID);
    final NumberFormat nf=NumberFormat.getCurrencyInstance(ID);
    final int green=Color.parseColor("#087F6A"), dark=Color.parseColor("#12312B"), text=Color.parseColor("#17202A"), muted=Color.parseColor("#667085"), bg=Color.parseColor("#F4F7F6"), line=Color.parseColor("#E2E8E6"), profit=Color.parseColor("#07855F"), blue=Color.parseColor("#2563EB"), orange=Color.parseColor("#C2410C");

    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}

    // Format nominal uang saat pengguna mengetik, tanpa mengganggu posisi kursor.
    void attachMoneyFormatter(final EditText editText){
        editText.addTextChangedListener(new TextWatcher(){
            boolean formatting=false;
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){}
            @Override public void afterTextChanged(Editable s){
                if(formatting) return;
                String digits=s.toString().replaceAll("[^0-9]","");
                if(digits.isEmpty()) return;
                try{
                    long value=Long.parseLong(digits);
                    String formatted=String.format(Locale.US,"%,d",value).replace(',','.');
                    if(!formatted.equals(s.toString())){
                        formatting=true;
                        editText.setText(formatted);
                        editText.setSelection(formatted.length());
                        formatting=false;
                    }
                }catch(Exception ignored){
                    formatting=false;
                }
            }
        });
    }

    // Ubah input nominal seperti "1.250.000" menjadi angka 1250000.
    double parseMoney(String value){
        if(value==null) return 0;
        String cleaned=value.replace("Rp","").replace("rp","")
                .replace(".","").replace(",","").trim();
        if(cleaned.isEmpty()) return 0;
        try{return Double.parseDouble(cleaned);}catch(Exception e){return 0;}
    }
    int screenDp(){return (int)(getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density+.5f);}
    boolean compact(){return screenDp()<380;}
    boolean tablet(){return screenDp()>=600;}
    int gap(){return tablet()?18:14;}

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        db=new DB(this);
        db.ensureSchema();
        setupWindow();
        buildShell();
        showPage(0);
    }
    void setupWindow(){
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        getWindow().setStatusBarColor(Color.parseColor("#075E50"));
        getWindow().setNavigationBarColor(Color.WHITE);
        if(Build.VERSION.SDK_INT>=23)getWindow().getDecorView().setSystemUiVisibility(0);
    }
    TextView tv(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);return t;}
    GradientDrawable box(String c,float r){GradientDrawable g=new GradientDrawable();g.setColor(Color.parseColor(c));g.setCornerRadius(dp(r));return g;}
    GradientDrawable stroke(String fill,String sc,float r){GradientDrawable g=box(fill,r);g.setStroke(dp(1),Color.parseColor(sc));return g;}
    LinearLayout.LayoutParams lp(int w,int h,float l,float t,float r,float b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}

    void buildShell(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.parseColor("#F6F8F8"));
// Beri ruang aman agar toolbar dan judul Dashboard tidak menempel/tertutup area atas.
root.setPadding(0,dp(8),0,0);
setContentView(root);

        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(10),dp(9),dp(10),dp(9));
        bar.setBackground(box("#08B5A0",24));

        TextView menu=iconButton("≡");menu.setOnClickListener(v->showSideMenu(v));
        bar.addView(menu,new LinearLayout.LayoutParams(dp(52),dp(52)));

        LinearLayout titleBox=col();titleBox.setGravity(Gravity.CENTER);
        TextView title=tv("Catatan Penjualan",19,Color.WHITE,true);title.setGravity(Gravity.CENTER);title.setTag("toolbarTitle");
        titleBox.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=tv("Catat - hitung - pantau",10,Color.parseColor("#D9FFFA"),false);sub.setGravity(Gravity.CENTER);
        titleBox.addView(sub,new LinearLayout.LayoutParams(-1,-2));
        bar.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));

        // Menu titik tiga kanan atas dihapus. Menu utama tetap tersedia melalui tombol ≡.
        root.addView(bar,new LinearLayout.LayoutParams(-1,-2));

        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setBackgroundColor(Color.parseColor("#F6F8F8"));
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
    }

    TextView iconButton(String icon){TextView t=tv(icon,23,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setClickable(true);t.setFocusable(true);t.setBackground(stroke("#18BDAA","#59D6C8",18));return t;}

    void showSideMenu(View anchor){
        LinearLayout menu=col();menu.setPadding(dp(12),dp(14),dp(12),dp(14));menu.setBackground(box("#FFFFFF",20));
        TextView head=tv("MENU",11,muted,true);head.setPadding(dp(8),dp(4),dp(8),dp(10));menu.addView(head);
        addMenuItem(menu,"Home","Dashboard",0);addMenuItem(menu,"+","Transaksi",1);addMenuItem(menu,"[]","Laporan",2);
        TextView prod=menuItem("Gear","Kelola Produk");prod.setOnClickListener(v->{if(sidePopup!=null)sidePopup.dismiss();manageProducts();});menu.addView(prod);
        TextView info=menuItem("i","Tentang aplikasi");info.setOnClickListener(v->{if(sidePopup!=null)sidePopup.dismiss();new AlertDialog.Builder(this).setTitle("Catatan Penjualan").setMessage("Aplikasi pencatatan penjualan sederhana untuk membantu mengelola transaksi, modal, kontrak, dan laba.").setPositiveButton("Tutup",null).show();});menu.addView(info);
        sidePopup=new PopupWindow(menu,dp(280),WindowManager.LayoutParams.WRAP_CONTENT,true);sidePopup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));sidePopup.setElevation(dp(12));sidePopup.setOutsideTouchable(true);
        sidePopup.showAtLocation(content,Gravity.TOP|Gravity.START,dp(10),dp(74));
    }
    PopupWindow sidePopup;
    void addMenuItem(LinearLayout menu,String icon,String label,int idx){TextView t=menuItem(icon,label);t.setOnClickListener(v->{if(sidePopup!=null)sidePopup.dismiss();content.post(() -> showPage(idx));});menu.addView(t);}
    TextView menuItem(String icon,String label){TextView t=tv(icon+"    "+label,14,text,true);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(14),0,dp(10),0);t.setBackground(stroke("#FFFFFF","#EEF2F1",15));t.setClickable(true);t.setMinHeight(dp(52));return t;}

    void showPage(int p){
        page=p;
        try{
            content.removeAllViews();
            if(p==0)dashboard(); else if(p==1)transactions(); else reports();
            updateToolbarTitle();
        }catch(Throwable e){
            content.removeAllViews();
            LinearLayout err=pageBody();
            err.addView(section("Transaksi tidak dapat dibuka"));
            err.addView(tv("Terjadi kesalahan saat membuka halaman. Data yang tersimpan tidak dihapus.",14,text,false),lp(-1,-2,0,0,0,12));
            err.addView(tv("Detail: "+e.getClass().getSimpleName()+" - "+String.valueOf(e.getMessage()),11,muted,false),lp(-1,-2,0,0,0,12));
            Button retry=primaryBtn("Coba lagi"); retry.setOnClickListener(v->showPage(p)); err.addView(retry,lp(-1,54,0,8,0,0));
            ScrollView sc=pageScroll();sc.addView(err);content.addView(sc);
            Toast.makeText(this,"Halaman gagal dibuka: "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show();
        }
    }
    void updateToolbarTitle(){TextView t=findToolbarTitle();if(t!=null){String s=page==0?"Dashboard":page==1?"Transaksi":"Laporan";t.setText(s);}}
    TextView findToolbarTitle(){View root=findViewById(android.R.id.content);return findTextWithTag(root,"toolbarTitle");}
    TextView findTextWithTag(View v,String tag){if(v instanceof TextView && tag.equals(v.getTag()))return (TextView)v;if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++){TextView r=findTextWithTag(g.getChildAt(i),tag);if(r!=null)return r;}}return null;}
    TextView section(String s){TextView t=tv(s,18,text,true);t.setPadding(0,dp(13),0,dp(8));return t;}
    String rp(double x){return nf.format(x).replace(",00","").replace("Rp","Rp ");}
    String today(){return sdf.format(new Date());}

    ScrollView pageScroll(){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setClipToPadding(false);s.setPadding(0,0,0,dp(6));return s;}
    LinearLayout pageBody(){LinearLayout l=col();int side=tablet()?28:16;l.setPadding(dp(side),dp(5),dp(side),dp(24));return l;}
    TextView moneyCard(String label,String value,String color){TextView t=tv(label+"\n"+value,compact()?11:12,Color.parseColor(color),true);t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(14),dp(11),dp(10),dp(11));t.setBackground(stroke("#FFFFFF",color,16));return t;}
    void addStatGrid(LinearLayout parent,String[][] data){
        int columns=tablet()?3:(compact()?1:2);
        LinearLayout current=null;
        for(int i=0;i<data.length;i++){
            if(i%columns==0){current=row();parent.addView(current,lp(-1,-2,0,i==0?0:10,0,0));}
            TextView card=moneyCard(data[i][0],data[i][1],data[i][2]);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(78),1);if(i%columns>0)p.setMargins(dp(7),0,0,0);current.addView(card,p);
        }
    }

    void dashboard(){
        ScrollView sc=pageScroll();LinearLayout root=pageBody();sc.addView(root);content.addView(sc);
        double[] a=db.summary(today(),today());double net=a[0]-a[3],lab=net-a[1];
        LinearLayout hero=col();hero.setPadding(dp(20),dp(18),dp(20),dp(18));hero.setBackground(box("#103D34",22));
        hero.addView(tv("Ringkasan hari ini",20,Color.WHITE,true));hero.addView(tv(new SimpleDateFormat("EEEE, dd MMMM yyyy",ID).format(new Date()),12,Color.parseColor("#BFE8DF"),false),lp(-1,-2,0,4,0,0));
        hero.addView(tv("OMSET BERSIH",11,Color.parseColor("#9ED9CE"),true),lp(-1,-2,0,18,0,0));hero.addView(tv(rp(net),30,Color.WHITE,true),lp(-1,-2,0,2,0,0));
        hero.addView(tv("Kotor "+rp(a[0])+"  -  Kontrak "+rp(a[3])+"  -  Laba "+rp(lab),12,Color.parseColor("#D8F5EF"),false),lp(-1,-2,0,7,0,0));root.addView(hero,lp(-1,-2,0,10,0,0));
        root.addView(section("Ikhtisar Keuangan"));addStatGrid(root,new String[][]{{"OMSET KOTOR",rp(a[0]),"#0F8F78"},{"UANG KONTRAK",rp(a[3]),"#C2410C"},{"MODAL",rp(a[1]),"#B7791F"},{"LABA BERSIH",rp(lab),"#07855F"}});
        double[] all=db.summary("01/01/1900","31/12/2999");double allNet=all[0]-all[3],allProfit=allNet-all[1];root.addView(section("Total sepanjang waktu"));addStatGrid(root,new String[][]{{"TOTAL OMSET BERSIH",rp(allNet),"#2563EB"},{"TOTAL LABA BERSIH",rp(allProfit),"#7C3AED"},{"TOTAL TRANSAKSI",String.valueOf((int)all[2]),"#475569"}});
        root.addView(section("Ringkasan Bulan Ini"));LinearLayout monthly=col();monthly.setPadding(dp(14),dp(13),dp(14),dp(13));monthly.setBackground(box("#FFFFFF",18));double[] m=db.monthSummary(new Date());double mn=m[0]-m[3],mp=mn-m[1];monthly.addView(tv(monthFmt.format(new Date()),14,text,true));addStatGrid(monthly,new String[][]{{"OMSET",rp(mn),"#087F6A"},{"MODAL",rp(m[1]),"#B7791F"},{"KONTRAK",rp(m[3]),"#2563EB"},{"LABA",rp(mp),"#7C3AED"}});monthly.addView(tv("Total transaksi bulan ini: "+(int)m[2],12,muted,true),lp(-1,-2,0,9,0,0));root.addView(monthly,lp(-1,-2,0,0,0,10));
        LinearLayout head=row();head.addView(section("Transaksi Terbaru"),new LinearLayout.LayoutParams(0,-2,1));Button see=smallBtn("Lihat semua");see.setOnClickListener(v->showPage(1));head.addView(see);root.addView(head);LinearLayout list=col();Cursor c=db.recentGrouped(5);while(c.moveToNext())list.addView(txCard(c,true),lp(-1,-2,0,0,0,9));c.close();if(list.getChildCount()==0)emptyState(list,"Belum ada transaksi","Tambahkan transaksi pertama dari menu Transaksi.");root.addView(list);
    }

    Button smallBtn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(green);b.setAllCaps(false);b.setMinHeight(dp(46));b.setGravity(Gravity.CENTER);b.setPadding(dp(12),0,dp(12),0);b.setBackground(stroke("#FFFFFF","#C9DED9",14));b.setClickable(true);b.setFocusable(true);return b;}
    Button primaryBtn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(dp(52));b.setGravity(Gravity.CENTER);b.setBackground(box("#087F6A",16));b.setClickable(true);b.setFocusable(true);return b;}
    void emptyState(LinearLayout parent,String title,String sub){LinearLayout e=col();e.setGravity(Gravity.CENTER);e.setPadding(dp(18),dp(22),dp(18),dp(22));e.setBackground(stroke("#FFFFFF","#E2E8E6",18));e.addView(tv(title,14,text,true));e.addView(tv(sub,12,muted,false),lp(-1,-2,0,5,0,0));parent.addView(e,lp(-1,-2,0,6,0,0));}

    void transactions(){
        ScrollView sc=pageScroll();LinearLayout root=pageBody();sc.addView(root);content.addView(sc);
        LinearLayout top=row();top.addView(section("Transaksi"),new LinearLayout.LayoutParams(0,-2,1));Button manage=smallBtn("Gear Produk");manage.setOnClickListener(v->manageProducts());top.addView(manage,new LinearLayout.LayoutParams(dp(150),dp(60)));root.addView(top);
        root.addView(tv("Buat satu transaksi dengan beberapa produk. Semua nominal dihitung otomatis dan tetap nyaman dipakai di HP kecil maupun tablet.",12,muted,false),lp(-1,-2,0,0,0,12));
        LinearLayout form=col();form.setPadding(dp(10),dp(12),dp(10),dp(14));form.setBackground(box("#FFFFFF",20));
        EditText date=field("Tanggal transaksi",false);date.setText(today());date.setFocusable(false);date.setClickable(true);date.setCompoundDrawablesWithIntrinsicBounds(0,0,android.R.drawable.ic_menu_my_calendar,0);date.setOnClickListener(v->pickDate(date));form.addView(date,lp(-1,72,0,0,0,12));
        form.addView(tv("ITEM TRANSAKSI",13,text,true),lp(-1,-2,0,2,0,10));LinearLayout itemRows=col();form.addView(itemRows,new LinearLayout.LayoutParams(-1,-2));addItemRow(itemRows);
        Button addItem=primaryOutlineBtn("＋  TAMBAH PRODUK");addItem.setTextSize(15);addItem.setOnClickListener(v->addItemRow(itemRows));form.addView(addItem,lp(-1,72,0,4,0,14));
        EditText sale=field("Total penjualan (Rp)",true);attachMoneyFormatter(sale);form.addView(sale,lp(-1,72,0,0,0,10));EditText capital=field("Total modal (Rp)",true);attachMoneyFormatter(capital);form.addView(capital,lp(-1,72,0,0,0,10));EditText note=field("Catatan (opsional)",false);form.addView(note,lp(-1,72,0,0,0,12));
        Button save=primaryBtn("✓  SIMPAN TRANSAKSI");save.setTextSize(16);form.addView(save,lp(-1,72,0,0,0,4));root.addView(form,lp(-1,-2,0,0,0,8));
        save.setOnClickListener(v->{try{String t=date.getText().toString();double totalSale=parseMoney(sale.getText().toString()),totalModal=parseMoney(capital.getText().toString());if(totalSale<=0||totalModal<0||itemRows.getChildCount()==0)throw new Exception();ArrayList<String> products=new ArrayList<>();ArrayList<Integer> qtys=new ArrayList<>();for(int i=0;i<itemRows.getChildCount();i++){View rr=itemRows.getChildAt(i);Object[] tags=(Object[])rr.getTag();AutoCompleteTextView sp=(AutoCompleteTextView)tags[0];EditText qe=(EditText)tags[1];String pr=sp.getText().toString().trim();int q=Integer.parseInt(qe.getText().toString().trim());if(pr.isEmpty()||pr.startsWith("Pilih")||pr.startsWith("Belum")||q<=0)throw new Exception();products.add(pr);qtys.add(q);}String group=UUID.randomUUID().toString();int totalQty=0;for(int q:qtys)totalQty+=q;for(int i=0;i<products.size();i++){double salePart=i==0?totalSale:0,modalPart=i==0?totalModal:0;db.add(t,products.get(i),qtys.get(i),totalQty>0?totalSale/totalQty:0,salePart,modalPart,note.getText().toString().trim(),group,i==0);}hideKeyboard();new AlertDialog.Builder(this).setTitle("Transaksi tersimpan").setMessage("Transaksi berhasil disimpan dan sudah masuk ke Ringkasan Hari Ini serta Riwayat Transaksi Hari Ini.").setPositiveButton("OK",(d,w)->transactions()).show();}catch(Exception e){Toast.makeText(this,"Lengkapi produk, jumlah, penjualan, dan modal",Toast.LENGTH_LONG).show();}});
        content.post(() -> {try{refreshTransactions(root);}catch(Throwable e){Toast.makeText(this,"Riwayat transaksi gagal dimuat",Toast.LENGTH_LONG).show();}});
    }
    Button primaryOutlineBtn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(green);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setGravity(Gravity.CENTER);b.setMinHeight(dp(58));b.setPadding(dp(12),0,dp(12),0);b.setBackground(stroke("#FFFFFF","#BFD4CF",16));b.setClickable(true);b.setFocusable(true);return b;}

    void addItemRow(LinearLayout parent){
        LinearLayout wrap=col();wrap.setPadding(dp(10),dp(10),dp(10),dp(10));wrap.setBackground(stroke("#FBFDFC","#DCE7E3",18));AutoCompleteTextView sp=productInput();EditText q=field("Jumlah pcs",true);q.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);q.setText("1");q.setTextSize(18);q.setSelectAllOnFocus(true);TextView del=actionButton("×");del.setTextSize(25);del.setTextColor(orange);del.setBackground(stroke("#FFFFFF","#E7D8D2",14));del.setOnClickListener(v->{if(parent.getChildCount()>1)parent.removeView(wrap);else Toast.makeText(this,"Minimal 1 produk",Toast.LENGTH_SHORT).show();});LinearLayout productLine=row();productLine.addView(sp,new LinearLayout.LayoutParams(0,dp(76),1));Button choose=primaryOutlineBtn("Pilih produk");choose.setTextSize(14);choose.setPadding(dp(10),0,dp(10),0);choose.setOnClickListener(v->showProductPicker(sp));productLine.addView(choose,new LinearLayout.LayoutParams(dp(150),dp(76)));wrap.addView(productLine);LinearLayout controls=row();controls.setPadding(0,dp(9),0,0);controls.addView(q,new LinearLayout.LayoutParams(0,dp(68),1));controls.addView(del,new LinearLayout.LayoutParams(dp(72),dp(68)));wrap.addView(controls);wrap.setTag(new Object[]{sp,q});parent.addView(wrap,lp(-1,-2,0,0,0,10));
    }

    ArrayList<String> productNames(){
        ArrayList<String> items=new ArrayList<>();
        Cursor c=null;
        try{
            c=db.products();
            while(c.moveToNext()) items.add(c.getString(0));
        }catch(Exception ignored){}finally{if(c!=null)c.close();}
        return items;
    }

    void showProductPicker(AutoCompleteTextView target){
        ArrayList<String> items=productNames();
        if(items.isEmpty()){
            new AlertDialog.Builder(this)
                .setTitle("Belum ada produk")
                .setMessage("Tambahkan produk terlebih dahulu melalui Gear Produk.")
                .setPositiveButton("Gear Produk",(d,w)->manageProducts())
                .setNegativeButton("Tutup",null).show();
            return;
        }
        String[] arr=items.toArray(new String[0]);
        new AlertDialog.Builder(this)
            .setTitle("Pilih produk")
            .setItems(arr,(d,which)->{
                target.setText(arr[which]);
                target.setSelection(target.length());
            })
            .setNegativeButton("Batal",null)
            .show();
    }

    AutoCompleteTextView productInput(){
        AutoCompleteTextView a=new AutoCompleteTextView(this);
        ArrayList<String> items=productNames();
        ArrayList<String> displayItems=new ArrayList<>(items);
        if(displayItems.isEmpty()) displayItems.add("Belum ada produk — buka Gear Produk");

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,displayItems);
        a.setAdapter(adapter);
        a.setThreshold(0);
        a.setHint("Pilih produk dari Gear Produk");
        a.setTextSize(18);
        a.setTextColor(text);
        a.setHintTextColor(Color.parseColor("#7D8996"));
        a.setSingleLine(true);
        a.setPadding(dp(18),0,dp(18),0);
        a.setGravity(Gravity.CENTER_VERTICAL);
        a.setBackground(stroke("#FFFFFF","#BFD4CF",18));
        a.setDropDownVerticalOffset(dp(4));
        a.setDropDownWidth(-1);
        a.setDropDownHeight(dp(260));
        a.setSelectAllOnFocus(false);
        a.setFocusable(true);
        a.setFocusableInTouchMode(true);
        a.setClickable(true);
        a.setOnFocusChangeListener((v,has)->{
            if(has) a.postDelayed(()->a.showDropDown(),100);
        });
        a.setOnClickListener(v->a.showDropDown());
        a.setOnItemClickListener((p,v,pos,id)->{
            String selected=p.getItemAtPosition(pos).toString();
            if(selected.startsWith("Belum ada produk")){
                a.setText("");
                manageProducts();
            }else{
                a.setText(selected);
                a.setSelection(a.length());
            }
        });
        return a;
    }

    TextView actionButton(String s){
        TextView t=tv(s,15,Color.WHITE,true);
        t.setGravity(Gravity.CENTER);
        t.setMinHeight(dp(54));
        t.setClickable(true);
        t.setFocusable(true);
        t.setIncludeFontPadding(true);
        t.setBackground(box("#087F6A",16));
        return t;
    }

    EditText field(String hint,boolean numeric){return field(hint,"",numeric);}
    EditText field(String hint,String val,boolean numeric){
        EditText e=new EditText(this);
        e.setHint(hint); e.setText(val); e.setTextSize(17); e.setTextColor(text);
        e.setHintTextColor(Color.parseColor("#7D8996"));
        e.setPadding(dp(18),0,dp(18),0); e.setSingleLine(true); e.setMinHeight(dp(58));
        e.setGravity(Gravity.CENTER_VERTICAL); e.setBackground(stroke("#FFFFFF","#C1D3CF",15));
        e.setFocusable(true); e.setFocusableInTouchMode(true); e.setClickable(true); e.setCursorVisible(true);
        e.setSelectAllOnFocus(false); e.setShowSoftInputOnFocus(true);
        e.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_NEXT);
        if(numeric){
            e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        } else {
            e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        }
        e.setOnTouchListener((v,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN){
                v.postDelayed(()->{
                    v.requestFocus();
                    InputMethodManager im=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                    if(im!=null) im.showSoftInput(v,InputMethodManager.SHOW_IMPLICIT);
                },50);
            }
            return false;
        });
        return e;
    }

    void manageProducts(){
        LinearLayout outer=col();outer.setPadding(dp(14),dp(4),dp(14),dp(2));EditText name=field("Nama produk, contoh: Topi",false);outer.addView(name,lp(-1,72,0,0,0,12));Button add=primaryBtn("＋  SIMPAN PRODUK");add.setTextSize(16);outer.addView(add,lp(-1,72,0,0,0,14));outer.addView(tv("PRODUK TERSIMPAN",12,muted,true),lp(-1,-2,0,0,0,7));LinearLayout list=col();ScrollView listScroll=new ScrollView(this);listScroll.setFillViewport(false);listScroll.addView(list,new ScrollView.LayoutParams(-1,dp(230)));outer.addView(listScroll,lp(-1,230,0,0,0,4));AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Gear Produk").setView(outer).setNegativeButton("Tutup",null).create();Runnable reload=()->{list.removeAllViews();ArrayList<String> products=productNames();if(products.isEmpty())emptyState(list,"Belum ada produk","Tambahkan produk menggunakan tombol SIMPAN PRODUK.");else for(String product:products){TextView item=tv("•  "+product,15,text,true);item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(12),0,dp(8),0);item.setBackground(stroke("#FFFFFF","#E2E8E6",14));list.addView(item,lp(-1,54,0,0,0,7));}};reload.run();add.setOnClickListener(v->{String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("Nama produk wajib diisi");return;}db.addProduct(n);name.setText("");reload.run();new AlertDialog.Builder(this).setTitle("Produk tersimpan").setMessage("Produk \""+n+"\" sudah tersimpan dan otomatis tersedia di pilihan produk pada Transaksi.").setPositiveButton("OK",null).show();});dlg.setOnDismissListener(v->{if(page==1)transactions();});dlg.show();Window w=dlg.getWindow();if(w!=null)w.setLayout(-1,WindowManager.LayoutParams.WRAP_CONTENT);
    }
    void pickDate(EditText target){Calendar c=Calendar.getInstance();try{c.setTime(sdf.parse(target.getText().toString()));}catch(Exception ignored){}new DatePickerDialog(this,(v,y,m,d)->{Calendar x=Calendar.getInstance();x.set(y,m,d);target.setText(sdf.format(x.getTime()));},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    void refreshTransactions(LinearLayout root){while(root.getChildCount()>3)root.removeViewAt(3);root.addView(section("Ringkasan Hari Ini"));addDailySummary(root,today());root.addView(section("Transaksi Hari Ini"));LinearLayout list=col();Cursor c=db.byDateGrouped(today());while(c.moveToNext())list.addView(txCard(c,false),lp(-1,-2,0,0,0,9));c.close();if(list.getChildCount()==0)emptyState(list,"Belum ada transaksi hari ini","Simpan transaksi pertama Anda untuk mulai melihat riwayat.");root.addView(list);}
    void addDailySummary(LinearLayout root,String date){double[] a=db.summary(date,date);double net=a[0]-a[3],lab=net-a[1];LinearLayout card=col();card.setPadding(dp(15),dp(14),dp(15),dp(14));card.setBackground(stroke("#FFFFFF","#DCE7E3",18));card.addView(tv("Ringkasan "+date,14,text,true));addStatGrid(card,new String[][]{{"OMSET KOTOR",rp(a[0]),"#087F6A"},{"MODAL",rp(a[1]),"#B7791F"},{"LABA BERSIH",rp(lab),"#07855F"}});LinearLayout bottom=row();bottom.addView(tv("Omset bersih  "+rp(net),14,text,true),new LinearLayout.LayoutParams(0,-2,1));Button contract=smallBtn("Uang kontrak");contract.setOnClickListener(v->showContractDialog(date));bottom.addView(contract);card.addView(bottom,lp(-1,-2,0,9,0,0));card.addView(tv("Kontrak "+rp(a[3])+"  -  "+(int)a[2]+" transaksi",12,muted,false),lp(-1,-2,0,6,0,0));root.addView(card,lp(-1,-2,0,0,0,10));}
    void showContractDialog(String date){EditText input=field("Nominal uang kontrak",true);attachMoneyFormatter(input);double current=db.getContract(date);if(current>0)input.setText(String.format(Locale.US,"%,d",(long)current).replace(',','.'));LinearLayout wrap=col();wrap.setPadding(dp(8),dp(4),dp(8),0);wrap.addView(input,new LinearLayout.LayoutParams(-1,54));AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Uang Kontrak - "+date).setMessage("Nominal ini mengurangi omset dan laba bersih pada tanggal tersebut.").setView(wrap).setNegativeButton("Batal",null).setNeutralButton("Hapus",null).setPositiveButton("Simpan",null).create();dlg.setOnShowListener(x->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{db.setContract(date,parseMoney(input.getText().toString()));dlg.dismiss();transactions();});dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{db.setContract(date,0);dlg.dismiss();transactions();});});dlg.show();}
    View txCard(Cursor c,boolean compactCard){long id=c.getLong(0);String date=c.getString(1),pr=c.getString(2);int q=c.getInt(3);double sale=c.getDouble(5),mo=c.getDouble(6),lb=sale-mo;String group=c.getString(8);String note=c.getString(7);LinearLayout card=col();card.setPadding(dp(15),dp(13),dp(15),dp(13));card.setBackground(stroke("#FFFFFF","#E5EBE9",16));LinearLayout top=row();top.addView(tv(pr,15,text,true),new LinearLayout.LayoutParams(0,-2,1));top.addView(tv(date,11,muted,false));card.addView(top);card.addView(tv("Jumlah "+q+" pcs  -  Total transaksi "+rp(sale),12,Color.parseColor("#475467"),false),lp(-1,-2,0,6,0,4));LinearLayout bottom=row();bottom.addView(tv("Modal "+rp(mo),12,Color.parseColor("#B7791F"),false),new LinearLayout.LayoutParams(0,-2,1));bottom.addView(tv("Laba "+rp(lb),13,lb>=0?profit:Color.RED,true));card.addView(bottom);if(!compactCard&&note!=null&&!note.isEmpty())card.addView(tv("Catatan: "+note,12,muted,false),lp(-1,-2,0,6,0,0));card.setOnLongClickListener(v->{new AlertDialog.Builder(this).setTitle("Hapus transaksi?").setMessage(pr+"\n"+rp(sale)).setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{db.delTransaction(group,id);if(page==1)transactions();else dashboard();}).show();return true;});return card;}
    Date reportDate=null;
    void reports(){ScrollView sc=pageScroll();LinearLayout root=pageBody();sc.addView(root);content.addView(sc);Date selected=reportDate==null?new Date():reportDate;LinearLayout head=col();head.setPadding(dp(19),dp(18),dp(19),dp(18));head.setBackground(box("#103D34",22));head.addView(tv("Laporan penjualan",21,Color.WHITE,true));head.addView(tv("Rekap omset, kontrak, modal, laba, dan transaksi.",12,Color.parseColor("#BFE8DF"),false),lp(-1,-2,0,4,0,0));head.addView(tv(monthFmt.format(selected),14,Color.WHITE,true),lp(-1,-2,0,16,0,0));root.addView(head,lp(-1,-2,0,10,0,12));LinearLayout picker=row();picker.addView(tv(monthFmt.format(selected),15,text,true),new LinearLayout.LayoutParams(0,50,1));Button month=smallBtn("Pilih bulan");picker.addView(month,new LinearLayout.LayoutParams(dp(120),50));month.setOnClickListener(v->pickMonth());root.addView(picker);
        double[] a=db.monthSummary(selected);double net=a[0]-a[3],lab=net-a[1];root.addView(section("Ringkasan Periode"));addStatGrid(root,new String[][]{{"OMSET BERSIH",rp(net),"#087F6A"},{"UANG KONTRAK",rp(a[3]),"#C2410C"},{"MODAL",rp(a[1]),"#B7791F"},{"LABA BERSIH",rp(lab),"#07855F"},{"TRANSAKSI",String.valueOf((int)a[2]),"#2563EB"}});
        root.addView(section("Detail Harian"));root.addView(tv("Geser tabel ke kiri/kanan pada layar kecil.",12,muted,false),lp(-1,-2,0,0,0,8));HorizontalScrollView hs=new HorizontalScrollView(this);LinearLayout table=col();table.setBackground(stroke("#FFFFFF","#DCE5E2",12));table.addView(reportRow(new String[]{"TANGGAL","PRODUK","TRX","OMSET","KONTRAK","BERSIH","MODAL","LABA"},true));Cursor c=db.dailyMonth(selected);int rows=0;while(c.moveToNext()){String day=c.getString(0),products=c.getString(1);int trx=c.getInt(2);double o=c.getDouble(3),m=c.getDouble(4),k=c.getDouble(5),n=o-k,l=n-m;table.addView(reportRow(new String[]{day,products==null?"-":products,String.valueOf(trx),rp(o),rp(k),rp(n),rp(m),rp(l)},false));rows++;}c.close();if(rows==0)table.addView(reportRow(new String[]{"Belum ada data","-","-","-","-","-","-","-"},false));hs.addView(table);root.addView(hs,lp(-1,-2,0,0,0,0));
        root.addView(section("Detail Transaksi"));
        root.addView(tv("Setiap transaksi dengan beberapa produk digabung menjadi satu baris.",12,muted,false),lp(-1,-2,0,0,0,8));
        HorizontalScrollView txHs=new HorizontalScrollView(this);
        LinearLayout txTable=col();txTable.setBackground(stroke("#FFFFFF","#DCE5E2",12));
        txTable.addView(reportRow(new String[]{"TANGGAL","ITEM TRANSAKSI","QTY","PENJUALAN","MODAL","LABA"},true));
        Cursor tc=db.transactionMonth(selected);int txRows=0;
        while(tc.moveToNext()){
            String day=tc.getString(0),items=tc.getString(1);int qty=tc.getInt(2);double sale=tc.getDouble(3),capital=tc.getDouble(4),profitValue=sale-capital;
            txTable.addView(reportRow(new String[]{day,items==null?"-":items,String.valueOf(qty),rp(sale),rp(capital),rp(profitValue)},false));txRows++;
        }
        tc.close();
        if(txRows==0)txTable.addView(reportRow(new String[]{"Belum ada data","-","-","-","-","-"},false));
        txHs.addView(txTable);root.addView(txHs,lp(-1,-2,0,0,0,0));
        LinearLayout total=col();total.setPadding(dp(15),dp(14),dp(15),dp(14));total.setBackground(box("#EEF8F5",16));total.addView(tv("TOTAL PERIODE",11,green,true));total.addView(tv("Omset kotor     "+rp(a[0])+"\nUang kontrak    "+rp(a[3])+"\nOmset bersih    "+rp(net)+"\nModal           "+rp(a[1])+"\nLaba bersih     "+rp(lab)+"\nTransaksi       "+(int)a[2],13,text,true),lp(-1,-2,0,8,0,0));root.addView(total,lp(-1,-2,0,10,0,0));Button share=smallBtn("Bagikan laporan");share.setOnClickListener(v->shareReport(a));root.addView(share,lp(-1,50,0,12,0,0));}
    View reportRow(String[] cells,boolean header){LinearLayout r=row();r.setPadding(dp(8),dp(10),dp(8),dp(10));r.setBackgroundColor(header?Color.parseColor("#EAF3F0"):Color.WHITE);int[] widths={95,230,55,125,105,125,105,125};for(int i=0;i<cells.length;i++){TextView t=tv(cells[i],header?10:11,header?dark:text,header||i==7);t.setGravity(i==0?Gravity.CENTER_VERTICAL:Gravity.CENTER);r.addView(t,new LinearLayout.LayoutParams(dp(widths[i]),-2));}return r;}
    void pickMonth(){Calendar c=Calendar.getInstance();Date base=reportDate==null?new Date():reportDate;c.setTime(base);new DatePickerDialog(this,(v,y,m,d)->{Calendar x=Calendar.getInstance();x.set(y,m,1);reportDate=x.getTime();reports();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),1).show();}
    void shareReport(double[] a){double net=a[0]-a[3],lab=net-a[1];String s="LAPORAN PENJUALAN\n"+monthFmt.format(reportDate==null?new Date():reportDate)+"\n\nOmset Kotor: "+rp(a[0])+"\nUang Kontrak: "+rp(a[3])+"\nOmset Bersih: "+rp(net)+"\nModal: "+rp(a[1])+"\nLaba Bersih: "+rp(lab)+"\nTransaksi: "+(int)a[2];Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Bagikan laporan"));}
    void hideKeyboard(){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(content.getWindowToken(),0);content.requestFocus();}

    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"sales.db",null,8);}

        public void onCreate(SQLiteDatabase d){
            createTables(d);
        }

        public void onUpgrade(SQLiteDatabase d,int oldVersion,int newVersion){
            createTables(d);
            ensureColumn(d,"sales","transaction_id","TEXT");
            ensureColumn(d,"sales","primary_item","INTEGER DEFAULT 1");
        }

        private void createTables(SQLiteDatabase d){
            d.execSQL("CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,tanggal TEXT,produk TEXT,jumlah INTEGER,harga REAL,penjualan REAL,modal REAL,catatan TEXT,transaction_id TEXT,primary_item INTEGER DEFAULT 1)");
            d.execSQL("CREATE TABLE IF NOT EXISTS contracts(tanggal TEXT PRIMARY KEY,nominal REAL NOT NULL DEFAULT 0)");
            d.execSQL("CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,nama TEXT UNIQUE NOT NULL)");
        }

        @Override public void onOpen(SQLiteDatabase d){
            super.onOpen(d);
            // Jangan mengubah struktur database dari onOpen. Migrasi dilakukan di onUpgrade.
        }

        void ensureSchema(){
            SQLiteDatabase d=getWritableDatabase();
            d.beginTransaction();
            try{
                createTables(d);
                ensureColumn(d,"sales","transaction_id","TEXT");
                ensureColumn(d,"sales","primary_item","INTEGER DEFAULT 1");
                d.setTransactionSuccessful();
            }finally{
                d.endTransaction();
            }
        }

        void ensureColumn(SQLiteDatabase d,String table,String column,String definition){
            Cursor c=null;
            boolean found=false;
            try{
                c=d.rawQuery("PRAGMA table_info("+table+")",null);
                int nameIndex=c.getColumnIndex("name");
                while(c.moveToNext()){
                    if(nameIndex>=0 && column.equals(c.getString(nameIndex))){
                        found=true;
                        break;
                    }
                }
            }catch(Exception ignored){}finally{
                if(c!=null)c.close();
            }
            if(!found){
                try{
                    d.execSQL("ALTER TABLE "+table+" ADD COLUMN "+column+" "+definition);
                }catch(Exception ignored){}
            }
        }

        void add(String t,String p,int q,double h,double j,double m,String c,String group,boolean primary){
            getWritableDatabase().execSQL(
                "INSERT INTO sales(tanggal,produk,jumlah,harga,penjualan,modal,catatan,transaction_id,primary_item) VALUES(?,?,?,?,?,?,?,?,?)",
                new Object[]{t,p,q,h,j,m,c,group,primary?1:0}
            );
        }

        void addProduct(String name){
            getWritableDatabase().execSQL("INSERT OR IGNORE INTO products(nama) VALUES(?)",new Object[]{name});
        }

        Cursor products(){
            return getReadableDatabase().rawQuery("SELECT nama FROM products ORDER BY nama COLLATE NOCASE",null);
        }

        void del(long id){getWritableDatabase().delete("sales","id=?",new String[]{String.valueOf(id)});}
        void delTransaction(String group,long fallbackId){SQLiteDatabase w=getWritableDatabase();if(group!=null&&!group.trim().isEmpty())w.delete("sales","transaction_id=?",new String[]{group});else w.delete("sales","id=?",new String[]{String.valueOf(fallbackId)});}
        Cursor byDate(String t){return byDateGrouped(t);}
        Cursor byDateGrouped(String t){return getReadableDatabase().rawQuery("SELECT MIN(id) AS id,tanggal,GROUP_CONCAT(produk,' + ') AS produk,SUM(jumlah) AS jumlah,MAX(harga) AS harga,SUM(penjualan) AS penjualan,SUM(modal) AS modal,MAX(catatan) AS catatan,transaction_id,1 AS primary_item FROM sales WHERE tanggal=? GROUP BY COALESCE(transaction_id,'legacy-'||id),tanggal ORDER BY MIN(id) DESC",new String[]{t});}
        Cursor recent(int n){return recentGrouped(n);}
        Cursor recentGrouped(int n){return getReadableDatabase().rawQuery("SELECT MIN(id) AS id,tanggal,GROUP_CONCAT(produk,' + ') AS produk,SUM(jumlah) AS jumlah,MAX(harga) AS harga,SUM(penjualan) AS penjualan,SUM(modal) AS modal,MAX(catatan) AS catatan,transaction_id,1 AS primary_item FROM sales GROUP BY COALESCE(transaction_id,'legacy-'||id),tanggal ORDER BY MIN(id) DESC LIMIT "+n,null);}

        double contract(String date){
            Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(nominal,0) FROM contracts WHERE tanggal=?",new String[]{date});
            double v=0;
            if(c.moveToFirst())v=c.getDouble(0);
            c.close();
            return v;
        }

        double getContract(String date){return contract(date);}

        void setContract(String date,double val){
            SQLiteDatabase w=getWritableDatabase();
            if(val<=0)w.delete("contracts","tanggal=?",new String[]{date});
            else w.execSQL("INSERT OR REPLACE INTO contracts(tanggal,nominal) VALUES(?,?)",new Object[]{date,val});
        }

        double[] summary(String from,String to){
            Cursor c=getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(penjualan),0),COALESCE(SUM(modal),0),COUNT(DISTINCT COALESCE(transaction_id,'legacy-'||id)),COALESCE((SELECT SUM(nominal) FROM contracts WHERE tanggal>=? AND tanggal<=?),0) FROM sales WHERE tanggal>=? AND tanggal<=?",
                new String[]{from,to,from,to}
            );
            c.moveToFirst();
            double[] a={c.getDouble(0),c.getDouble(1),c.getDouble(2),c.getDouble(3)};
            c.close();
            return a;
        }

        double[] monthSummary(Date d){
            Calendar x=Calendar.getInstance();
            x.setTime(d);
            String prefix=new SimpleDateFormat("MM/yyyy",Locale.US).format(x.getTime());
            Cursor c=getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(penjualan),0),COALESCE(SUM(modal),0),COUNT(DISTINCT COALESCE(transaction_id,'legacy-'||id)),COALESCE((SELECT SUM(nominal) FROM contracts WHERE substr(tanggal,4,7)=?),0) FROM sales WHERE substr(tanggal,4,7)=?",
                new String[]{prefix,prefix}
            );
            c.moveToFirst();
            double[] a={c.getDouble(0),c.getDouble(1),c.getDouble(2),c.getDouble(3)};
            c.close();
            return a;
        }

        Cursor transactionMonth(Date d){
            Calendar x=Calendar.getInstance();x.setTime(d);String prefix=new SimpleDateFormat("MM/yyyy",Locale.US).format(x.getTime());
            return getReadableDatabase().rawQuery(
                "SELECT s.tanggal,GROUP_CONCAT(s.produk,' + '),SUM(s.jumlah),SUM(s.penjualan),SUM(s.modal) FROM sales s WHERE substr(s.tanggal,4,7)=? GROUP BY COALESCE(s.transaction_id,'legacy-'||s.id),s.tanggal ORDER BY MIN(s.id) DESC",
                new String[]{prefix}
            );
        }

        Cursor dailyMonth(Date d){
            Calendar x=Calendar.getInstance();
            x.setTime(d);
            String prefix=new SimpleDateFormat("MM/yyyy",Locale.US).format(x.getTime());
            return getReadableDatabase().rawQuery(
                "SELECT s.tanggal,group_concat(s.produk,' - '),COUNT(DISTINCT COALESCE(s.transaction_id,'legacy-'||s.id)),SUM(s.penjualan),SUM(s.modal),COALESCE((SELECT nominal FROM contracts ct WHERE ct.tanggal=s.tanggal),0) FROM sales s WHERE substr(s.tanggal,4,7)=? GROUP BY s.tanggal ORDER BY s.tanggal DESC",
                new String[]{prefix}
            );
        }
    }
}
